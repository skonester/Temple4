<img width="240" src="https://raw.githubusercontent.com/orhun/ratty/refs/heads/main/website/assets/images/ratty-logo.gif" alt="Ratty logo" />

> **Ratty**: A GPU-rendered terminal emulator with inline 3D graphics 🧀  
> [ratty-term.org](https://ratty-term.org)

## 0.4.0 - 2026-05-18

Read the **It's FOSS** article about Ratty: ["This New Terminal is Absurd (But Totally Fun)"](https://itsfoss.com/ratty-terminal/)

The highlight of this release is [**ratSCAD**](https://github.com/qewer33/ratscad), a terminal CAD application built with Ratty by @qewer33!  
Here is the demo:

<div>
  <video src="https://github.com/user-attachments/assets/7fe31947-b734-4d19-9fba-ef606cc7b975" alt="Ratscad Demo"/>
</div>

### Download Ratty

From [crates.io](https://crates.io/crates/ratty):

```bash
cargo install ratty
```

From [Arch Linux repositories](https://archlinux.org/packages/extra/x86_64/ratty/):

```bash
pacman -S ratty
```

Or download binary releases:

| File                                                                                                                                     | Platform            | Checksum                                                                                                          |
| ---------------------------------------------------------------------------------------------------------------------------------------- | ------------------- | ----------------------------------------------------------------------------------------------------------------- |
| [ratty-aarch64-apple-darwin.tar.xz](https://github.com/orhun/ratty/releases/download/v0.4.0/ratty-aarch64-apple-darwin.tar.xz)           | Apple Silicon macOS | [checksum](https://github.com/orhun/ratty/releases/download/v0.4.0/ratty-aarch64-apple-darwin.tar.xz.sha256)      |
| [ratty-x86_64-apple-darwin.tar.xz](https://github.com/orhun/ratty/releases/download/v0.4.0/ratty-x86_64-apple-darwin.tar.xz)             | Intel macOS         | [checksum](https://github.com/orhun/ratty/releases/download/v0.4.0/ratty-x86_64-apple-darwin.tar.xz.sha256)       |
| [ratty-aarch64-unknown-linux-gnu.tar.xz](https://github.com/orhun/ratty/releases/download/v0.4.0/ratty-aarch64-unknown-linux-gnu.tar.xz) | ARM64 Linux         | [checksum](https://github.com/orhun/ratty/releases/download/v0.4.0/ratty-aarch64-unknown-linux-gnu.tar.xz.sha256) |
| [ratty-x86_64-unknown-linux-gnu.tar.xz](https://github.com/orhun/ratty/releases/download/v0.4.0/ratty-x86_64-unknown-linux-gnu.tar.xz)   | x64 Linux           | [checksum](https://github.com/orhun/ratty/releases/download/v0.4.0/ratty-x86_64-unknown-linux-gnu.tar.xz.sha256)  |

### Features

- Support scrolling with trackpad by @orhun in [#54](https://github.com/orhun/ratty/pull/54)
- Support clipboard on Wayland by default by @TheCodedKid in [#47](https://github.com/orhun/ratty/pull/47)
- Select the correct default shell on Windows by @ahostbr in [#66](https://github.com/orhun/ratty/pull/66)

### Bug Fixes

- Allow absolute paths for objects by @orhun in [#56](https://github.com/orhun/ratty/pull/56)
- Add some options for font fallback by @orhun in [#55](https://github.com/orhun/ratty/pull/55)
  - Update parley_ratatui version to 0.2.1 by @gold-silver-copper in [#57](https://github.com/orhun/ratty/pull/57)
- Use transparency while rendering cells by @orhun in [#53](https://github.com/orhun/ratty/pull/53)
- Use synthetic mouse events for scrolling in apps by @orhun in [#63](https://github.com/orhun/ratty/pull/63)
- Enable shading for all objects by @qewer33 in [#62](https://github.com/orhun/ratty/pull/62)
- Keep rendering smooth when the window is unfocused by @orhun

### New Contributors

- @ahostbr made their first contribution in [#66](https://github.com/orhun/ratty/pull/66)
- @qewer33 made their first contribution in [#62](https://github.com/orhun/ratty/pull/62)
- @gold-silver-copper made their first contribution in [#57](https://github.com/orhun/ratty/pull/57)
- @TheCodedKid made their first contribution in [#47](https://github.com/orhun/ratty/pull/47)

**Full Changelog**: https://github.com/orhun/ratty/compare/v0.3.0...0.4.0

## 0.3.0 - 2026-05-13

Read **The Register** article about Ratty: ["Rodent-obsessed developer creates Ratty to bring 3D graphics to the command line"](https://www.theregister.com/software/2026/05/11/ratty-terminal-emulator-brings-3d-graphics-to-the-command-line/5238299)

<div>
  <video src="https://github.com/user-attachments/assets/a81598a9-e57c-4ba7-b840-5044e6e279cf" alt="Ratty Demo"/>
</div>

### Features

- Support transform and update control for 3D objects by @orhun in [#39](https://github.com/orhun/ratty/pull/39)

You can now set the position, rotation and scale of inline 3D objects in Ratty and update them in-place after placement.

The following RGP sequence first registers (`r`) an object, then places it (`p`) and finally updates its rotation, position and brightness (`u`).

```text
ESC _ ratty;g;r;id=7;fmt=glb;path=SpinyMouse.glb ESC \
ESC _ ratty;g;p;id=7;row=5;col=10;w=3;h=2;depth=1.5;rx=0;ry=30;rz=0;sx=1;sy=1;sz=1 ESC \
ESC _ ratty;g;u;id=7;ry=120;px=0.25;brightness=1.2 ESC \
```

<details>
  <summary>Example usage in Rust</summary>

```rust
use ratatui_core::{buffer::Buffer, layout::Rect, widgets::Widget};
use ratatui_ratty::{ObjectFormat, RattyGraphic, RattyGraphicSettings};

let mut graphic = RattyGraphic::new(
    RattyGraphicSettings::new("assets/objects/SpinyMouse.glb")
        .id(7)
        .format(ObjectFormat::Glb)
        .rotation([0.0, 30.0, 0.0])
        .scale3([1.0, 1.0, 1.0]),
);

graphic.register()?;

let mut buf = Buffer::empty(Rect::new(0, 0, 80, 24));
(&graphic).render(Rect::new(10, 5, 24, 10), &mut buf);

graphic.settings_mut().rotation = [0.0, 120.0, 0.0];
graphic.settings_mut().brightness = 1.2;
graphic.update()?;
```

</details>

- Support inline payloads by @orhun in [#41](https://github.com/orhun/ratty/pull/41)

You can now register 3D objects from payload data sent directly over the Ratty Graphics Protocol, without needing to provide a local file path first.

This will make it possible to e.g. send 3D object data from SSH sessions! 🎉

Example registration pipeline (with `source=payload` and `more` fields to indicate chunking):

```text
ESC _ ratty;g;r;id=42;fmt=obj;source=payload;more=1;name=rat.obj;<base64 chunk 1> ESC \
ESC _ ratty;g;r;id=42;fmt=obj;source=payload;more=1;<base64 chunk 2> ESC \
ESC _ ratty;g;r;id=42;fmt=obj;source=payload;more=0;<base64 chunk N> ESC \
ESC _ ratty;g;p;id=42;row=12;col=8;w=4;h=2 ESC \
```

<details>
  <summary>Example usage in Rust</summary>

```rust
use ratatui_ratty::{ObjectFormat, RattyGraphic, RattyGraphicSettings};

let graphic = RattyGraphic::new(
    RattyGraphicSettings::new("live_draw.obj")
        .id(42)
        .format(ObjectFormat::Obj),
);

let obj_bytes = std::fs::read("live_draw.obj")?;

graphic.register_payload(&obj_bytes)?;
```

</details>

- Support keyboard scrollback navigation by @orhun in [#35](https://github.com/orhun/ratty/pull/35)

Here are new (customizable) key bindings for navigating Ratty's local scrollback without using the mouse:

- `Alt+PageUp`: scroll one page up
- `Alt+PageDown`: scroll one page down
- `Alt+Up`: scroll one line up
- `Alt+Down`: scroll one line down

### Bug Fixes

- Fall back to `$SHELL` or `/bin/sh` by default by @orhun in [#36](https://github.com/orhun/ratty/pull/36)

### Documentation

- Update README.md to run the install command for arch and dependency install commands for other Distros by @zalanwastaken in [#38](https://github.com/orhun/ratty/pull/38)
- Document necessary prerequisites for Linux by @jokeyrhyme in [#10](https://github.com/orhun/ratty/pull/10)

### New Contributors

- @zalanwastaken made their first contribution in [#38](https://github.com/orhun/ratty/pull/38)
- @jokeyrhyme made their first contribution in [#10](https://github.com/orhun/ratty/pull/10)

**Full Changelog**: https://github.com/orhun/ratty/compare/v0.2.0...0.3.0

## 0.2.0 - 2026-05-11

We're excited to announce the first public release of Ratty! 🐁

- Read the blog: https://blog.orhun.dev/introducing-ratty
- Demo video: https://www.youtube.com/watch?v=cY9AX5j-osY

<div>
  <video src="https://github.com/user-attachments/assets/17eda86b-d00f-401b-9cf4-38343fa71386" alt="Ratty Demo"/>
</div>

- docs: expand installation section by @orhun
- chore: adjust the release workflow by @orhun
- chore: update changelog header by @orhun
- chore: update changelog header by @orhun

## 0.1.0-rc.1 - 2026-05-10

- chore: release 0.1.0 of ratatui-ratty by @orhun
- chore: expand the target checks in CI by @orhun
- chore: set up release workflow by @orhun
- chore: add macos build step by @orhun
- docs: update video link in website by @orhun
- docs: add link to demo video by @orhun
- refactor: apply clippy suggestions by @orhun
- chore: add libfontconfig1-dev as dependency by @orhun
- style: run rustfmt by @orhun
- chore: add missing CI dependencies by @orhun
- refactor: apply clippy suggestions by @orhun
- style: run rustfmt by @orhun
- chore: add CI by @orhun
- Add release profile by @pythops in [#21](https://github.com/orhun/ratty/pull/21)
- fix: use the workspace root in widget examples by @orhun
- feat: add CLI arguments by @orhun
- feat: add animation to mobius mode by @orhun
- chore: exclude assets from the crates.io release by @orhun
- chore: update og:description for the website by @orhun
- chore: add website by @orhun
- refactor!: rename ToggleMode to Toggle3DMode by @orhun
- feat: add mobius mode by @orhun
- chore: set widget version by @orhun
- fix: apply the bob animation in 3D mode by @orhun
- feat: support color while configuring the cursor by @orhun
- fix: handle numlock-off keypad navigation keys by @orhun
- chore: add Ferris object for fun by @orhun
- feat: support enhanced keyboard reporting for modified special keys by @orhun
- feat: support window transparency by @orhun
- docs: add tetro-tui demo video by @orhun
- chore: add metadata by @orhun
- chore: set RC version by @orhun
- docs: update logo style by @orhun
- docs: update logo by @orhun
- perf: reduce runtime CPU and memory footprint by @EzgiTastan in [#18](https://github.com/orhun/ratty/pull/18)
- fix: handle \x1b[0c and \x1b[5n by @orhun
- fix: handle cursor position report request by @orhun
- style: tweak the badge by @orhun
- docs: add logo by @orhun
- revert: update description by @orhun
- style: update description by @orhun
- docs: add emoji by @orhun
- docs: add project description by @orhun
- docs: librarify ratty by @orhun
- feat: support theming by @orhun
- feat: support resetting the font size by @orhun
- refactor: simplify runtime and system state handling by @orhun
- chore: update default font by @orhun
- chore: add issue and PR templates by @orhun
- style: update documentation style by @orhun
- docs: add widget documentation by @orhun
- docs: add CoC by @orhun
- docs: add contribution guide by @orhun
- docs: add security policy by @orhun
- docs: remove description by @orhun
- docs: reorder sections by @orhun
- docs: expand documentation and add demos by @orhun
- fix(terminal): normalize HVP cursor positioning by @orhun
- refactor: reorder systems module definitions by @orhun
- refactor: apply clippy suggestions by @orhun
- fix: honor the application cursor for keys by @orhun
- chore: enable sponsorships by @orhun
- docs: update the project features by @orhun
- feat: add mouse drawing demo by @orhun
- feat: render image in the editor demo by @orhun
- feat: add inline object demos by @orhun
- feat: add a ratatui widget for RGP by @orhun
- feat: support animate and scale in RGP by @orhun
- feat: support GLB files by @orhun
- feat: implement Ratty Graphics Protocol (RGP) by @orhun
- docs: update the syntax by @orhun
- docs: update the syntax by @orhun
- docs: update the demo by @orhun
- fix: make the images affect by warp by @orhun
- refactor: simplify image anchor handling by @orhun
- feat: add experimental image support via kitty by @orhun
- fix: warp the cursor model by @orhun
- feat: apply warp animation by @orhun
- perf: defer the cursor model spawn by @orhun
- perf: lazy-init off-screen GPU by @orhun
- feat: embed models into the binary by @orhun
- chore: update default key bindings by @orhun
- refactor: support loading fonts from system by @orhun
- feat: support configuration by @orhun
- feat: support changing font size by @orhun
- chore: support x-offset for the cursor by @orhun
- refactor: switch to parley_ratatui for rendering by @orhun
- feat: support debug view in 3D mode by @orhun
- feat: support 3D mode by @orhun
- feat: support ctrl+arrow combinations by @orhun
- perf: add terminal redraw optimization by @orhun
- chore: switch to parley-vello by @orhun
- feat: support clipboard by @orhun
- refactor: handle the input combinations better by @orhun
- feat: set window scale factor by @orhun
- chore: bump soft_ratatui by @orhun
- docs: add README.md by @orhun
- style: switch to JetBrains mono font by @orhun
- revert: switch to embedded-ttf for font rendering by @orhun
- chore: switch to embedded-ttf for font rendering by @orhun
- chore: clean up assets by @orhun
- chore: license under MIT by @orhun
- perf: load the model after terminal initialization by @orhun
- style: switch to dark theme by @orhun
- chore: remove the window padding by @orhun
- feat: support resize by @orhun
- refactor: use a widget renderer for the terminal by @orhun
- feat: support space key by @orhun
- chore: switch to cosmic-text backend by @orhun
- refactor: split into modules by @orhun
- chore: bump bevy to 0.18 by @orhun
- chore: rename project by @orhun
- feat: implement cursor as 3d model by @orhun
- Add model by @orhun
- Simple terminal implementation by @orhun

### New Contributors

- @orhun made their first contribution
- @pythops made their first contribution in [#21](https://github.com/orhun/ratty/pull/21)
- @EzgiTastan made their first contribution in [#18](https://github.com/orhun/ratty/pull/18)

<!-- generated by git-cliff -->
